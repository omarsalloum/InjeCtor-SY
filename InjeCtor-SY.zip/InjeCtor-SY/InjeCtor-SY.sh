#!/bin/bash
# Coded By Omar Salloum #
#     Date 2\10\2016    #
#########################
sleep 0.1
echo "$(tput bold)$( tput setaf 10)~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~$(tput sgr0)"

sleep 0.1
echo "$( tput setaf 10)~                                                          ~"
sleep 0.1
echo "~                    ######   ##    ##                     ~"
sleep 0.1 
echo "~                   ##    ##   ##  ##                      ~ "
sleep 0.1
echo "~                   ##          ####                       ~"
sleep 0.1
echo "~                    ######      ##                        ~"
sleep 0.1
echo "~                         ##     ##                        ~"
sleep 0.1
echo "~                   ##    ##     ##                        ~"
sleep 0.1
echo "~                    ######      ##                        ~ "
sleep 0.1
echo "$( tput setaf 10)~                                                          ~$(tput sgr0)"
sleep 0.1
echo "$( tput setaf 10)~ $(tput sgr0)                  © Syrian St0rm                         $( tput setaf 10)~$(tput sgr0)"
sleep 0.1
echo "$( tput setaf 10)~                                                          ~$(tput sgr0)"
sleep 0.1
echo "$(tput bold)$( tput setaf 10)~$(tput sgr0)                 $(tput bold)$( tput setaf 1)SQL-Injection Tools                      $(tput bold)$( tput setaf 10)~$(tput sgr0)"
sleep 0.1
echo "$( tput setaf 10)~                                                          ~$(tput sgr0)"
sleep 0.1
echo "$(tput bold)$( tput setaf 10)~$(tput sgr0)             Coded By :$(tput bold)$( tput setaf 4) Th3 Syrian St0rm                  $(tput bold)$( tput setaf 10)~$(tput sgr0)"  
sleep 0.1
echo "$(tput bold)$( tput setaf 10)~$(tput sgr0)               E-mail : $(tput bold)$( tput setaf 4)o90@live.se                       $( tput setaf 10)~$(tput sgr0)"
sleep 0.1
echo "$(tput bold)$( tput setaf 10)~$(tput sgr0)            Tested on : $(tput bold)$( tput setaf 4)Kali/Ubuntu/Parrot                $(tput bold)$( tput setaf 10)~$(tput sgr0)"
sleep 0.1
echo "$( tput setaf 10)~                                                          ~$(tput sgr0)"
echo "$(tput bold)$( tput setaf 10)~   The Coder Is Not Responsible For Any Harmfull Results  ~$(tput sgr0)"
sleep 0.1
echo "$(tput bold)$( tput setaf 10)~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~$(tput sgr0)"
echo " "
sleep 1
echo "$(tput bold)$( tput setaf 1)+$(tput sgr0) $( tput setaf 10)$(tput bold) Choose A Number $(tput bold)$( tput setaf 1):$(tput sgr0)"
echo ""
echo "  $( tput setaf 10)1$(tput sgr0)$(tput bold)$( tput setaf 1).$(tput sgr0) $( tput setaf 10)$(tput bold) SQL-Ininjection exploit $(tput bold)$( tput setaf 1).$(tput sgr0)"
echo ""
echo "  $( tput setaf 10)2$(tput sgr0)$(tput bold)$( tput setaf 1).$(tput sgr0) $( tput setaf 10)$(tput bold) Find Admin-panel $(tput bold)$( tput setaf 1).$(tput sgr0)"
echo ""
echo "  $( tput setaf 10)3$(tput sgr0)$(tput bold)$( tput setaf 1).$(tput sgr0) $( tput setaf 10)$(tput bold) HASH Cracking $(tput bold)$( tput setaf 1).$(tput sgr0)"
echo " "
echo "  $( tput setaf 10)4$(tput sgr0)$(tput bold)$( tput setaf 1).$(tput sgr0) $( tput setaf 10)$(tput bold) Exit $(tput bold)$( tput setaf 1).$(tput sgr0)$( tput setaf 10)"
read number
case "$number" in 
'1') 
bash tools/sql.tar;;
'2')
perl tools/cp.tar;;
'3')
echo " $(tput bold)$( tput setaf 1)>$(tput sgr0)$( tput setaf 10)$(tput bold) Please Enter The Hash You Would Want To Crack It $( tput setaf 1):$(tput sgr0)"
read pass
perl tools/md5brute.tar luns 1 10 $pass &bash InjeCtor-SY.sh;;
'4')
clear& exit;;
esac 
